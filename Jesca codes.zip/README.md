# VicTech Electronics
## Final_projects_2022-23
These are the project from Victech ELectronic for final year 
Engineering students 2022/23 from defferent Colleges and Universities
